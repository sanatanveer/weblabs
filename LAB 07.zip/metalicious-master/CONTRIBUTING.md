We accept pull requests! We also want to protect your intellectual rights. Pull request authors must sign the Contributor License Agreement before it will be merged into origin/master. To get started, review and sign the [CLA](http://www.clahub.com/agreements/Chicago/metalicious).

Have concerns about the CLA? We would appreciate any feedback at this [gist](https://gist.github.com/tomschenkjr/5777509).
