	</div>
	
</div> <!-- /content -->
					
	
<div id="footer">
	
	<div class="container">				
		<hr>
		<p>&copy; 2012 Go Ideate.</p>
	</div> <!-- /container -->
	
</div> <!-- /footer -->


    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../../assets/js/vendor/jquery-1.7.2.min.js"></script>
<script src="../../assets/js/vendor/excanvas.min.js"></script>
<script src="../../assets/js/vendor/jquery.flot.js"></script>
<script src="../../assets/js/vendor/jquery.flot.pie.js"></script>
<script src="../../assets/js/vendor/jquery.flot.orderBars.js"></script>
<script src="../../assets/js/vendor/jquery.flot.resize.js"></script>


<script src="../assets/js/vendor/bootstrap.js"></script>
<script src="../assets/js/vendor/charts/bar.js"></script>

  </body>
</html>
