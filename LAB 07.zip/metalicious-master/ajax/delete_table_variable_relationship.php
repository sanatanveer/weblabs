<?php
include '../classes/table.php';

Table::delete_table_variable_relationship($_POST['Table_Variable_ID']);

?>
