<?php
include '/include/header.php';

?>

<!-- container started in header.php -->

    <div class="main">
      <div class="row-fluid">
          <div class="span3">
              <h1>Browse</h1>
          </div>
          <div class="span9">
              <h1>Business Functions</h1>
          </div>
      </div> <!-- /row -->
    </div> <!-- /main -->



<?php include 'include/footer.php'; ?>
