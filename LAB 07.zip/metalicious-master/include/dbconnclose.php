<?php
// Close db connection
mysqli_close($cnnCDD);
?>
