
    <hr>
    
    <footer>
        <p>City of Chicago licensed this site under <a href="http://opensource.org/licenses/MIT" target="license_window">MIT License</a>.</p>
    </footer>

</div> <!-- /container -->

    <script src="https://app.divshot.com/js/bootstrap.min.js"></script>
    <!-- <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script> -->
  </body>

</html>